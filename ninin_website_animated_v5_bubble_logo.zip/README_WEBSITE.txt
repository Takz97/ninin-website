ninin Website — Animated v2

This is an updated static website prototype with subtle motion:
- hero and section reveal animations
- floating author desk/book treatment
- hover lift and gold accent interactions
- soft ambient background motion
- reduced-motion accessibility support

Open index.html in a browser to preview it locally.

The Windows download link expects:
downloads/ninin Setup 1.0.0.exe

Do not publish until the final installer, support contact, privacy wording, and release information have been verified.


V5 opening animation:
The site now opens with a black-screen ninin logo inspired by the supplied reference. The white logo has a soft liquid/bubble motion, small bubbles rise around it, and the intro fades into the main site automatically. Reduced-motion users receive a shorter, non-animated intro.


V5 bubble-logo refinement:
The opening logo now uses thick rounded, inflated lettering with glossy highlights, soft depth, liquid distortion, gentle breathing, rising bubbles, and water ripples. The letters themselves are designed to read as large drops of water / balloon-like bubbles rather than flat text.
